// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = true
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')


onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})

onEvent('recipes', event => {
	// Remove recipes by mod here
	event.remove({mod: 'exnihilosequentia'})
	event.remove({mod: 'usrg'})
	event.remove({mod: 'cobblefordays'})
})

onEvent('recipes', event => {
	//Temporally remove mods that cannot be started
	event.remove({mod: 'chemlib'})
	event.remove({mod: 'alchemistry'})
	event.remove({mod: 'astralsorcery'})
	event.remove({mod: 'draconicevolution'})
	event.remove({mod: 'envirocore'})
	event.remove({mod: 'mysticalagriculture'})
	event.remove({mod: 'powah'})
	event.remove({mod: 'projecte'})
	event.remove({mod: 'projectex'})
	event.remove({mod: 'rftools'})
	event.remove({mod: 'tconstruct'})
	event.remove({mod: 'woot'})
	event.remove({mod: 'cyclic'})
	event.remove({mod: 'eidolon'})
})

onEvent('recipes', event => {
	// Remove recipes by id here
	event.remove({id: 'minecraft:clay'})
	event.remove({id: 'minecraft:clay_ball'})
	event.remove({id: 'minecraft:cobblestone'})
	event.remove({id: 'minecraft:iron_ingot'})
	event.remove({id: 'minecraft:glowstone_dust'})
	event.remove({id: 'minecraft:glowstone'})
	event.remove({id: 'integrateddynamics:crystalized_menril_chunk'})
	event.remove({id: 'thermal:sulfur'})
	event.remove({id: 'thermal:sulfur_dust'})
	event.remove({id: 'minecraft:black_dye'})
	event.remove({id: 'botania:dye_black'})
	event.remove({id: 'thermal:machine_frame'})
	event.remove({id: 'mekanism:steel_casing'})
})

onEvent('recipes', event => {
	// Remove recipe by output here
	event.remove({output: 'minecraft:clay'})
	event.remove({output: 'minecraft:clay_ball'})
	event.remove({output: 'minecraft:iron_ingot'})
	event.remove({output: 'minecraft:glowstone_dust'})
	event.remove({output: 'minecraft:glowstone'})
	event.remove({output: 'minecraft:gravel'})
	event.remove({output: 'integrateddynamics:crystalized_menril_block'})
	event.remove({output: 'tconstruct:molten_clay'})
	event.remove({output: 'tconstruct:molten_clay_bucket'})
	event.remove({output: 'minecraft:blue_dye'})
	event.remove({output: '#create:crushed_ores'})
})

onEvent('recipes', event => {
    //Replace recipes here
	event.replaceInput({type: 'minecraft:crafting_shaped'}, 'minecraft:dried_kelp', 'thermal:rubber')
})

// Custom event for draconicevolution crafting
let draconicFusion = (e, output, craftingTier, energy, middleItem, ingredientList) => {
	//crafting tier: 1.draconium, 2.wyvern, 3.draconic, 4.chaotic
	let tiers = ['WYVERN', 'DRACONIC', 'CHAOTIC']
	e.custom({
	  type: 'draconicevolution:fusion_crafting',
	  result: { item: output },
	  catalyst: { item: middleItem },
	  total_energy: energy,
	  tier: (craftingTier > 4 && craftingTier <= 1) ? 'DRACONIUM' : tiers[craftingTier - 2],
	  ingredients: ingredientList.map(item => (item.charAt(0) === '#') ? { tag: item.substring(1) } : { item: item })
	}).id(`kubejs:fusion_crafting/${output.replace(':', '/')}`)
  }
  let energize = (e, ingredient, result, power, count) => {
	e.recipes.powah.energizing({
	  ingredients: ingredient.map(i => Ingredient.of(i).toJson()),
	  energy: power,
	  result: Item.of(result, count ? count : 1).toResultJson()
	}).id(`kubejs:energizing/${result.replace(':', '/')}`)
  }

onEvent('recipes', event => {
	// Add shapeless recipes here
	event.shapeless('minecraft:oak_planks',['4x minecraft:stick'])
	event.shapeless('minecraft:glowstone_dust',['minecraft:iron_pickaxe', 'minecraft:torch', 'exnihilosequentia:dust']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('minecraft:redstone',['minecraft:iron_pickaxe', 'minecraft:torch', 'minecraft:gravel']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('minecraft:gravel',['minecraft:iron_pickaxe', 'minecraft:cobblestone']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('minecraft:sand',['minecraft:iron_pickaxe', 'minecraft:gravel']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('3x minecraft:dirt',['minecraft:cobblestone', 'minecraft:gravel', 'minecraft:sand'])
	event.shapeless('2x integrateddynamics:menril_berries', ['minecraft:apple', 'integrateddynamics:crystalized_menril_chunk'])
	event.shapeless('integrateddynamics:crystalized_menril_block', ['9x integrateddynamics:crystalized_menril_chunk'])
	event.shapeless('exnihilosequentia:dust',['minecraft:iron_pickaxe', 'minecraft:sand']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('minecraft:blue_dye',['botania:blue_petal', 'botania:pestle_and_mortar']).keepIngredient('botania:pestle_and_mortar')
	event.shapeless('3x minecraft:blue_dye',['minecraft:lapis_lazuli'])
	event.shapeless('thermal:sulfur_dust',['thermal:sulfur', 'minecraft:iron_pickaxe']).damageItem('minecraft:iron_pickaxe', '1')
	event.shapeless('minecraft:quartz',['minecraft:glowstone_dust', 'minecraft:bone_meal'])
})

onEvent('recipes', event => {
	// Add shaped recipes here
	event.shaped('3x integrateddynamics:crystalized_menril_chunk',[
		' D ',
		'PG ',
		' S '
	],{
		D: 'minecraft:dirt',
		P: Item.of('minecraft:iron_pickaxe').ignoreNBT(),
		G: 'minecraft:glowstone_dust',
		S: 'minecraft:sand'
	}).damageItem('minecraft:iron_pickaxe', '1')
	event.shaped('minecraft:oak_sapling',[
		' X ',
		'XMX',
		' X '
	],{
		X: 'compressedblocks:c0_dirt',
		M: 'integrateddynamics:crystalized_menril_chunk'
	})
	event.shaped('integratedterminals:menril_glass',[
		' M ',
		'MGM',
		' M '
	],{
		M: 'integrateddynamics:crystalized_menril_chunk',
		G: '#forge:glass'
	})
	event.shaped('minecraft:water_bucket',[
		'LLL',
		'LBL',
		'LLL'
	],{
		L: 'minecraft:oak_leaves',
		B: 'minecraft:bucket'
	})
	event.shaped('4x minecraft:slime_ball',[
		'LDL',
		'DWD',
		'LDL'
	],{
		L: 'minecraft:oak_leaves',
		D: 'minecraft:dirt',
		W: 'minecraft:water_bucket'
	})
	event.shaped('create:andesite_cobblestone',[
		' G ',
		'GCG',
		' G '
	],{
		C: 'minecraft:cobblestone',
		G: 'minecraft:gravel'
	})
	event.shaped('create:blaze_burner',[
		'IGI',
		'BCB',
		'IGI'
	],{
		I: 'minecraft:iron_block',
		G: 'minecraft:glowstone',
		C: 'minecraft:coal_block',
		B: 'minecraft:iron_bars'
	})
	event.shaped('4x minecraft:bone_meal',[
		' D ',
		'DID',
		' D '
	],{
		D: 'exnihilosequentia:dust',
		I: 'minecraft:dirt'
	})
	
	event.shaped('usrg:cobblegenerator',[
		'CcC',
		'LGW',
		'CcC'
	],{
		C: 'compressedblocks:c0_cobblestone',
		c: 'minecraft:cobblestone',
		G: 'minecraft:glass',
		L: 'minecraft:lava_bucket',
		W: 'minecraft:water_bucket'
	})
	event.shaped('cobblefordays:tier_3',[
		'III',
		'GCG',
		'III'
	],{
		I: 'minecraft:iron_ingot',
		G: 'minecraft:glass',
		C: 'usrg:cobblegenerator'
	})
	event.shaped('cobblefordays:tier_4',[
		'III',
		'GCG',
		'III'
	],{
		I: 'minecraft:gold_ingot',
		G: 'minecraft:glass',
		C: 'cobblefordays:tier_3'
	})
	event.shaped('cobblefordays:tier_5',[
		'DDD',
		'GCG',
		'DDD'
	],{
		D: 'minecraft:diamond',
		G: 'minecraft:glass',
		C: 'cobblefordays:tier_4'
	})
	event.shaped('thermal:machine_frame',[
		'IGI',
		'GFG',
		'IGI'
	],{
		I: 'minecraft:iron_ingot',
		G: 'minecraft:glass',
		F: 'create:copper_casing'
	})
	event.shaped('mekanism:steel_casing',[
		'SGS',
		'GFG',
		'SGS'
	],{
		S: '#forge:ingots/steel',
		G: 'minecraft:glass',
		F: 'thermal:machine_frame'
	})
	event.shaped('appliedenergistics2:name_press',[
		' S ',
		'SIS',
		' S '
	],{
		S: 'refinedstorage:silicon',
		I: 'minecraft:iron_block'
	})
	event.shaped('appliedenergistics2:silicon_press',[
		'   ',
		' I ',
		' S '
	],{
		S: 'refinedstorage:silicon',
		I: 'minecraft:iron_block'
	})
	event.shaped('appliedenergistics2:logic_processor_press',[
		'   ',
		' IS',
		'   '
	],{
		S: 'refinedstorage:silicon',
		I: 'minecraft:iron_block'
	})
	event.shaped('appliedenergistics2:engineering_processor_press',[
		' S ',
		' I ',
		'   '
	],{
		S: 'refinedstorage:silicon',
		I: 'minecraft:iron_block'
	})
	event.shaped('appliedenergistics2:calculation_processor_press',[
		'   ',
		'SI ',
		'   '
	],{
		S: 'refinedstorage:silicon',
		I: 'minecraft:iron_block'
	})
})

onEvent('recipes', event => {
	//Add smelting recipes here
	event.smelting('minecraft:obsidian',['compressedblocks:c1_cobblestone'])
	event.smelting('4x minecraft:iron_ingot', ['compressedblocks:c0_cobblestone'])
	event.smelting('8x minecraft:iron_ingot',['create:crushed_iron_ore'])
	event.smelting('4x thermal:copper_ingot',['compressedblocks:c0_gravel'])
	event.smelting('8x thermal:copper_ingot',['create:crushed_copper_ore'])
	event.smelting('4x thermal:silver_ingot', ['excompressum:compressed_dust'])
})

onEvent('recipes', event => {
	//Create Mixing recipes here
	event.recipes.createMixing('minecraft:gold_ingot',['4x minecraft:glowstone_dust','minecraft:iron_ingot']).heated()
	event.recipes.createMixing('minecraft:coal',['4x minecraft:charcoal']).heated()
	event.recipes.createMixing(Fluid.of('kubejs:basic_petally_fluid', 500),['#botania:petals',Fluid.of('minecraft:water',1000)])
	event.recipes.createMixing(Fluid.of('kubejs:poorly_concentrated_petally_fluid', 500),['minecraft:bone_meal',Fluid.of('kubejs:basic_petally_fluid',1000)])
	event.recipes.createMixing(Fluid.of('kubejs:concentrated_petally_fluid', 500),['minecraft:glowstone_dust',Fluid.of('kubejs:poorly_concentrated_petally_fluid',1000)])
	event.recipes.createMixing(Fluid.of('kubejs:highly_concentrated_petally_fluid', 500),['minecraft:gold_ingot',Fluid.of('kubejs:concentrated_petally_fluid',1000)]).heated()
	event.recipes.createMixing(Fluid.of('kubejs:liquid_dirt', 250),['minecraft:dirt',Fluid.of('minecraft:water',500)])
	event.recipes.createMixing(Fluid.of('tconstruct:molten_lead',144),[Fluid.of('tconstruct:molten_iron',144), Fluid.of('tconstruct:molten_obsidian',250)]).heated()
	event.recipes.createMixing(Fluid.of('tconstruct:molten_iron',144),['minecraft:iron_ingot']).heated()
	event.recipes.createMixing(Fluid.of('tconstruct:molten_obsidian',1000),['minecraft:obsidian']).heated()
	event.recipes.createMixing('8x minecraft:snowball',['minecraft:ice'])
	event.recipes.createMixing('2x minecraft:gunpowder',['minecraft:charcoal', 'thermal:sulfur_dust'])
	event.recipes.createMixing('minecraft:black_dye',['minecraft:charcoal','exnihilosequentia:dust'])
	event.recipes.createMixing('create:zinc_ingot',['minecraft:iron_ingot', 'minecraft:bone_meal'])
	event.recipes.createMixing('immersiveengineering:ingot_aluminum',['create:zinc_ingot', '4x minecraft:bone_meal'])
	event.recipes.createMixing(Fluid.of('minecraft:lava', 250), ['#forge:cobblestone']).heated()
	event.recipes.createMixing(Fluid.of('thermal:latex', 50),['#minecraft:flowers', Fluid.of('minecraft:water',100)])
	event.recipes.createMixing(Fluid.of('thermal:latex', 75),['#minecraft:leaves', Fluid.of('minecraft:water',250)])
	event.recipes.createMixing(Fluid.of('thermal:latex', 150),['#minecraft:logs', Fluid.of('minecraft:water',500)])
	event.recipes.createMixing('thermal:rubber',[Fluid.of('thermal:latex', 250)])
	event.recipes.createMixing('2x thermal:rubber',[Fluid.of('thermal:latex', 500)])
	event.recipes.createMixing('4x thermal:rubber',[Fluid.of('thermal:latex', 1000)])
})

onEvent('recipes', event => {
	//Create Pressing recipes here
	event.recipes.createPressing('minecraft:diamond',['compressedblocks:c0_coal_block']).heated()
})

onEvent('recipes', event => {
	//Create Compacting recipes here
	event.recipes.createCompacting('minecraft:terracotta',[Fluid.of('kubejs:liquid_dirt', 1000)])
	event.recipes.createCompacting('minecraft:ice',[Fluid.of('minecraft:water',1000)])
	event.recipes.createCompacting('thermal:sulfur',['minecraft:glowstone_dust','exnihilosequentia:dust'])
})

onEvent('recipes', event => {
	//Create Milling recipes here
	event.recipes.createMilling('2x create:crushed_copper_ore',['compressedblocks:c0_gravel'])
	event.recipes.createMilling('2x create:crushed_tin_ore',['compressedblocks:c0_sand'])
	event.recipes.createMilling('create:crushed_silver_ore',['excompressum:compressed_dust'])
	event.recipes.createMilling(['create:crushed_iron_ore',Item.of('thermal:nickel_dust').withChance(0.1)],'minecraft:iron_ore')
	event.recipes.createMilling(['2x create:crushed_iron_ore'], 'compressedblocks:c0_cobblestone')
})

onEvent('recipes', event => {
	//Create Filling recipe here
	event.recipes.createFilling('minecraft:netherrack',[Fluid.of('minecraft:lava',1000), 'minecraft:stone'])
	event.recipes.createFilling('minecraft:iron_ore',[Fluid.of('tinkers:molten_iron',1000), 'minecraft:stone'])
})

onEvent('recipes', event => {
	//Thermal Chiller recipes here
	event.recipes.thermal.chiller('minecraft:iron_ingot',[Fluid.of('tconstruct:molten_iron',144), 'thermal:chiller_ingot_cast']).energy(5000)
})

onEvent('recipes', event => {
	//Thermal Fractioning Still recipes here
	event.recipes.thermal.refinery(Fluid.of('tconstruct:molten_nickel',144), [Fluid.of('tconstruct:molten_iron',144)])
	event.recipes.thermal.refinery('minecraft:lapis_lazuli',[Fluid.of('kubejs:concentrated_blue_liquid',125)])
})

onEvent('recipes', event => {
	//Thermal Magma Crucible recipes here
	event.recipes.thermal.crucible(Fluid.of('tconstruct:molten_iron',144),['minecraft:iron_ingot'])
})

onEvent('recipes', event => {
	//Thermal Alchemical Imbuer recipes here
	event.recipes.thermal.brewer(Fluid.of('kubejs:lowly_blue_liquid', 250),[Fluid.of('kubejs:highly_concentrated_petally_fluid',500), 'botania:blue_petal']).energy(10000)
	event.recipes.thermal.brewer(Fluid.of('kubejs:glowy_blue_liquid', 250),[Fluid.of('kubejs:lowly_blue_liquid',500), 'minecraft:glowstone_dust']).energy(15000)
	event.recipes.thermal.brewer(Fluid.of('kubejs:precious_blue_liquid', 250),[Fluid.of('kubejs:glowy_blue_liquid',500), 'minecraft:gold_ingot']).energy(20000)
	event.recipes.thermal.brewer(Fluid.of('kubejs:concentrated_blue_liquid', 250),[Fluid.of('kubejs:precious_blue_liquid',500), 'minecraft:blue_dye']).energy(25000)
})

onEvent('recipes', event => {
	//Mekanism Enrichment recipes here
	event.recipes.mekanismEnriching('appliedenergistics2:certus_quartz_crystal',['minecraft:quartz'])
})

onEvent('recipes', event => {
	//Draconic fusion recipes here
	event.custom({
		type: 'draconicevolution:fusion_crafting',
		result: {item: 'minecraft:clay_ball'},
		catalyst: {item: 'draconicevolution:chaotic_core'},
		total_energy: 1000000000000,
		tier: 'CHAOTIC',
		ingredients: [{item: 'minecraft:snowball'}]
	})
})

onEvent('recipes', event => {
	//Extended Crafting recipes here
	event.recipes.extendedcrafting.shaped_table('minecraft:black_dye',[
		'IIIII',
		'I   I',
		'IIIII'
	],{
		I: 'minecraft:ink_sac',
		
	})
})

